/**
 * Package that contains all classes for the graphical user interface of SUDOKUH.
 *
 * @author Philipp Kremling
 * @author Fabian Heinl
 */
package view;
