@file:Suppress("SpellCheckingInspection")

rootProject.name = "sudokuh"
