/**
 * Package that contains Presenters that connect the {@link model model package} with the {@link view view package}.
 *
 * @author Philipp Kremling
 * @author Fabian Heinl
 */
package presenter;
