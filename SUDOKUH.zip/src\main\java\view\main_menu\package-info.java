/**
 * Package that contains all classes for the graphical user interface of SUDOKUH's main menu.
 *
 * @author Philipp Kremling
 * @author Fabian Heinl
 */
package view.main_menu;
