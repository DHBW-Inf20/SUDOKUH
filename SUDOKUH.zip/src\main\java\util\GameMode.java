package util;

/**
 * @author Philipp Kremling
 */
public enum GameMode {
    SUDOKU_PLAY, SUDOKU_SOLVE, STR8TS_SOLVE, KILLER_SOLVE
}
