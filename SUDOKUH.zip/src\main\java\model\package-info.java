/**
 * Package that contains all classes related to generating, manipulating, solving and holding state of puzzles.
 *
 * @author Luca Kellermann
 */
package model;
