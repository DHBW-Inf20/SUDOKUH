/**
 * Package that contains all classes shared across other packages.
 */
package util;
